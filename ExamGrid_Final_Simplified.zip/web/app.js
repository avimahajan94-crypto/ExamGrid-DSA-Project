const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const state = {
  view: 'dashboard', dashboard: null, centres: [], candidates: [], audit: [], queue: [],
  selectedCentre: 'C001', selectedHall: 1, selectedSeat: null, currentOperation: 'overview', toastTimer: null,
};

const pageMeta = {
  dashboard: ['OVERVIEW', 'Overview', 'Manage candidates, seats and examination-day operations.'],
  candidates: ['CANDIDATES', 'Candidates', 'Search or register synthetic candidates. IDs are indexed by a binary search tree.'],
  seating: ['SEATING PLAN', 'Seating plan', 'Inspect seats by centre and hall, or find a candidate using their application ID.'],
  operations: ['OPERATIONS', 'Operations', 'Allocate seats, process check-in, test a centre disruption, or lock the plan.'],
  audit: ['AUDIT TRAIL', 'Audit trail', 'Review the chronological record of changes stored in a linked list.'],
};

const dsaContent = {
  overview: {
    title: 'Data structures at work', glyph: '{ }', structure: 'Arrays + BST', operation: 'C++ state and candidate index',
    description: 'ExamGrid uses manually implemented data structures for candidate indexing, seat allocation and operations. Select an action to see the algorithm behind it.',
    steps: ['Candidate records are stored in a fixed-capacity array.', 'The BST indexes candidate IDs for search and sorted listing.', 'All dashboard values are returned by the C++ process.'], complexity: 'Depends on operation'
  },
  candidateSearch: {
    title: 'Candidate lookup', glyph: '↗', structure: 'Binary Search Tree', operation: 'Compare key, follow left or right child',
    description: 'The application ID is compared with the key at the current BST node. A smaller ID follows the left pointer; a larger ID follows the right pointer until the record is found or a null link is reached.',
    steps: ['Start at the BST root.', 'Compare the requested ID with the current node key.', 'Follow the left or right link; stop on a match or missing child.'], complexity: 'Average O(log N) · worst O(N)'
  },
  candidateRegister: {
    title: 'Candidate insertion', glyph: '+', structure: 'Candidate array + BST', operation: 'Validate ID, then insert BST index node',
    description: 'A new candidate record is stored in the fixed-capacity array. The BST receives the array index as its payload and orders that index by application ID, allowing later lookup and inorder listing.',
    steps: ['Validate required fields and check for duplicate IDs.', 'Write the candidate record into the next free array position.', 'Insert the record index at the correct BST position.'], complexity: 'Average O(log N) · worst O(N)'
  },
  candidatesList: {
    title: 'Sorted candidate listing', glyph: '≋', structure: 'Binary Search Tree', operation: 'Inorder traversal',
    description: 'The listing is not sorted with a separate JavaScript sort. The C++ engine traverses the BST in left-node-right order, which returns IDs in ascending order because the tree is keyed by application ID.',
    steps: ['Traverse the left subtree.', 'Visit the current node and output its candidate record.', 'Traverse the right subtree.'], complexity: 'O(N) for a full traversal'
  },
  allocation: {
    title: 'Seat allocation', glyph: '▦', structure: 'Arrays + 2D seat grids', operation: 'Place each eligible candidate in a free seat',
    description: 'C++ walks the candidate array, tries the preferred cities first, then examines active centres and their 2D hall arrays. The first free cell stores that candidate’s array index; row and column become the seat coordinates.',
    steps: ['Check whether the plan is unlocked and allocation is allowed.', 'Visit candidates in the array and try preferred centres first.', 'Scan hall arrays for a free cell, store the candidate index and update the record.'], complexity: 'Worst-case O(N × S)'
  },
  seating: {
    title: 'Hall seating layout', glyph: '[ ]', structure: 'Two-dimensional array', operation: 'Directly map row × column to a seat',
    description: 'Each hall owns a fixed grid. A cell contains a candidate index, or −1 if the seat is empty. Clicking a cell in the website reads the seating grid returned by C++; the browser does not calculate or invent seat assignments.',
    steps: ['Choose the examination centre and hall.', 'Read each row and column from the C++ seat grid.', 'Render occupied, empty and checked-in seats differently.'], complexity: 'O(R × C) to render the grid'
  },
  queuePrepare: {
    title: 'Prepare check-in', glyph: '⇥', structure: 'Circular FIFO queue', operation: 'Enqueue eligible candidates',
    description: 'The C++ engine scans allocated candidates and enqueues those who have not checked in. The queue is circular, so the head and tail wrap around the fixed array without shifting all remaining items.',
    steps: ['Clear the previous check-in queue.', 'Scan the candidate array for allocated, not-yet-checked-in records.', 'Enqueue eligible candidate indexes in arrival order.'], complexity: 'O(N) to prepare · O(1) enqueue'
  },
  queueProcess: {
    title: 'Process next check-in', glyph: '→', structure: 'Circular FIFO queue', operation: 'Dequeue the next eligible candidate',
    description: 'The queue removes its head item, then the engine marks the corresponding candidate as checked in and appends an audit event. The earliest queued candidate is processed first.',
    steps: ['Read the queue head and advance it modulo the queue capacity.', 'Mark the candidate record as checked in.', 'Push its index to the manual check-in undo stack and append an audit event.'], complexity: 'O(1) dequeue'
  },
  checkinUndo: {
    title: 'Undo last check-in', glyph: '↶', structure: 'Manual stack', operation: 'Pop the most recent check-in action',
    description: 'A stack stores candidate indexes for recent check-ins. Undo pops the most recent index and reverses that candidate’s check-in state. The queue is cleared to avoid stale ordering and must be prepared again.',
    steps: ['Check whether the check-in history stack is non-empty.', 'Pop the last candidate index.', 'Reverse the check-in flag, clear the stale queue and log the reversal.'], complexity: 'O(1) stack pop'
  },
  disruption: {
    title: 'Centre disruption', glyph: '!', structure: 'Seat arrays + undo stack', operation: 'Disable centre, recover candidates, report overflow',
    description: 'The engine takes a snapshot of allocation state on a manual LIFO stack, marks the centre unavailable, frees its seats, and attempts to place displaced candidates at other active centres without exceeding capacity.',
    steps: ['Push a snapshot of the current allocation onto the undo stack.', 'Mark the centre offline and clear affected assignments.', 'Rebuild seat grids, reallocate displaced candidates, and count unresolved candidates.'], complexity: 'Worst-case O(N × S)'
  },
  undoAllocation: {
    title: 'Undo allocation change', glyph: '↶', structure: 'Manual LIFO stack', operation: 'Restore the most recent allocation snapshot',
    description: 'The top snapshot contains candidate seat coordinates and centre availability. Popping it restores the previous state, rebuilds the BST index and seat grids, and appends an audit entry describing the undo.',
    steps: ['Pop the latest snapshot from the undo stack.', 'Restore allocations, check-in flags and centre availability.', 'Rebuild the BST and 2D seat grids, then record the undo.'], complexity: 'O(N + total seats)'
  },
  planLock: {
    title: 'Plan state validation', glyph: '▣', structure: 'Boolean state + linked-list audit', operation: 'Guard allocation mutations',
    description: 'A plan-locked flag blocks edits to seating allocations. Lock and unlock actions are added to the audit trail so the simulated coordinator can trace when operational changes were permitted.',
    steps: ['Validate the current plan state and allocation readiness.', 'Set the locked/unlocked flag.', 'Append a timestamped audit event.'], complexity: 'O(1) state change + O(1) append'
  },
  audit: {
    title: 'Audit history', glyph: '≡', structure: 'Singly linked list', operation: 'Append and traverse event nodes',
    description: 'Each operational event is stored in its own linked-list node. A tail pointer lets the C++ program append a new event without shifting previous events; viewing the recent trail traverses those nodes.',
    steps: ['Create a node containing the timestamp and event message.', 'Link the current tail to the new node and move the tail pointer.', 'Traverse the chain to display the recent event history.'], complexity: 'O(1) append · O(N) traversal'
  },
  centreAdd: {
    title: 'Centre capacity setup', glyph: '▤', structure: 'Fixed arrays + 2D seat grids', operation: 'Add centre, halls and capacity',
    description: 'Centre records are kept in a fixed-capacity C++ array. Each centre contains a fixed number of hall definitions, and each hall has a 2D seat array sized by its configured rows and columns.',
    steps: ['Validate centre ID, dimensions and configured limits.', 'Append the centre record to the centre array.', 'Initialise each hall’s seat grid with −1 to mark every seat as free.'], complexity: 'O(H × R × C) to initialise'
  },
  import: {
    title: 'CSV roster import', glyph: '⇧', structure: 'Array + BST duplicate check', operation: 'Parse and insert valid records',
    description: 'The C++ importer parses candidate rows, validates required fields and attempts to insert each unique application ID into the BST. Duplicate or malformed rows are counted as skipped instead of overwriting existing records.',
    steps: ['Read CSV lines and split the four expected fields.', 'Validate the application ID and candidate name.', 'Insert each valid record into the array and BST; count rejected rows.'], complexity: 'O(M × tree insertion cost)'
  }
};

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function number(value) { return Number(value || 0).toLocaleString('en-IN'); }
function pct(value) { return `${Math.max(0, Math.min(100, Number(value || 0))).toFixed(1)}%`; }
function formBody(data) { return new URLSearchParams(data).toString(); }

async function request(path, data = null, method = 'GET') {
  const options = { method, headers: {} };
  if (method !== 'GET' && data !== null) {
    options.headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
    options.body = formBody(data);
  }
  const response = await fetch(path, options);
  const type = response.headers.get('content-type') || '';
  if (!response.ok) {
    if (type.includes('application/json')) throw new Error((await response.json()).message || `Request failed (${response.status})`);
    throw new Error(`Request failed (${response.status})`);
  }
  if (type.includes('application/json')) return response.json();
  return response.text();
}

function toast(message, isError = false) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.toggle('error', isError);
  el.classList.add('show');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => el.classList.remove('show'), 3400);
}

function setDsa(key, overrides = {}) {
  const content = {...(dsaContent[key] || dsaContent.overview), ...overrides};
  state.currentOperation = key;
  $('#dsa-title').textContent = content.title;
  $('#dsa-glyph').textContent = content.glyph;
  $('#dsa-structure').textContent = content.structure;
  $('#dsa-operation').textContent = content.operation;
  $('#dsa-description').textContent = content.description;
  $('#dsa-complexity').textContent = content.complexity;
  const steps = $('#dsa-steps');
  steps.replaceChildren();
  content.steps.forEach(step => { const li = document.createElement('li'); li.textContent = step; steps.append(li); });
  const trace = $('#operation-trace');
  if (trace) {
    trace.innerHTML = `<div class="trace-step"><span>→</span><div><b>${escapeHtml(content.title)}</b><p>${escapeHtml(content.operation)}. ${escapeHtml(content.description)}</p><p><strong>Complexity:</strong> ${escapeHtml(content.complexity)}</p></div></div>`;
  }
}

function navigate(view) {
  if (!pageMeta[view]) return;
  state.view = view;
  $$('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.view === view));
  $$('.view').forEach(section => section.classList.toggle('active-view', section.id === `view-${view}`));
  $('#crumb-current').textContent = pageMeta[view][0];
  $('#page-title').innerHTML = `${escapeHtml(pageMeta[view][1])}<span>.</span>`;
  $('#page-subtitle').textContent = pageMeta[view][2];
  window.scrollTo({top: 0, behavior: 'smooth'});
  if (view === 'dashboard') setDsa('overview');
  if (view === 'candidates') { setDsa('candidatesList'); loadCandidates(); }
  if (view === 'seating') { setDsa('seating'); loadSeatMap(); }
  if (view === 'audit') { setDsa('audit'); loadAudit(); }
  if (view === 'operations') { if (!['allocation','queuePrepare','queueProcess','checkinUndo','disruption','undoAllocation','planLock'].includes(state.currentOperation)) setDsa('allocation'); loadQueue(); }
}

function renderCentres(centres) {
  state.centres = centres || [];
  $('#centre-cards').innerHTML = state.centres.length ? state.centres.map((c, i) => {
    const initials = c.city.slice(0, 2).toUpperCase();
    return `<div class="centre-row"><div class="centre-identity"><div class="centre-monogram">${escapeHtml(initials)}</div><div><b>${escapeHtml(c.name)}</b><small>${escapeHtml(c.id)} · ${escapeHtml(c.city)} · ${c.hallCount} halls</small></div></div><div class="centre-capacity"><div class="capacity-label"><span>${number(c.occupied)} / ${number(c.capacity)} seats</span><b>${pct(c.utilisation)}</b></div><div class="progress-track"><div class="progress-fill ${c.available ? '' : 'offline'}" style="width:${c.available ? c.utilisation : 0}%"></div></div></div><div class="centre-state ${c.available ? '' : 'offline'}">${c.available ? '● ACTIVE' : '● OFFLINE'}</div></div>`;
  }).join('') : '<div class="empty-state">No centres configured. Add one from the centre management workflow.</div>';
  $('#centre-summary').textContent = `${state.centres.filter(c => c.available).length} active · ${state.centres.filter(c => !c.available).length} offline`;
  fillCentreSelects();
  fillPreferenceOptions();
}

function fillCentreSelects() {
  const selects = [$('#seat-centre'), $('#failure-centre')].filter(Boolean);
  selects.forEach(select => {
    const previous = select.value || (select.id === 'seat-centre' ? state.selectedCentre : '');
    const options = select.id === 'failure-centre' ? state.centres.filter(c => c.available) : state.centres;
    select.innerHTML = options.map(c => `<option value="${escapeHtml(c.id)}">${escapeHtml(c.city)} · ${escapeHtml(c.id)}${c.available ? '' : ' (OFFLINE)'}</option>`).join('');
    if (options.some(c => c.id === previous)) select.value = previous;
    else if (options.length) select.value = options[0].id;
  });
  if ($('#failure-centre') && !state.centres.some(c => c.id === $('#failure-centre').value && c.available)) {
    const active = state.centres.find(c => c.available);
    if (active) $('#failure-centre').value = active.id;
  }
  updateHallOptions();
}

function fillPreferenceOptions() {
  const cities = [...new Set(state.centres.map(c => c.city).filter(Boolean))];
  ['preference1', 'preference2'].forEach((name, index) => {
    const select = $(`#candidate-form select[name="${name}"]`);
    if (!select) return;
    const previous = select.value;
    select.innerHTML = (index === 1 ? '<option value="">No second preference</option>' : '') + cities.map(city => `<option value="${escapeHtml(city)}">${escapeHtml(city)}</option>`).join('');
    if (cities.includes(previous)) select.value = previous;
    else if (cities.length) select.value = index === 0 ? cities[0] : (cities[1] || '');
  });
}

function updateStats(stats) {
  $('#stat-candidates').textContent = number(stats.totalCandidates);
  $('#stat-allocated').textContent = number(stats.allocated);
  $('#stat-capacity').textContent = number(stats.freeSeats ?? Math.max(0, stats.capacity - stats.allocated));
  $('#stat-checked').textContent = number(stats.checkedIn);
  $('#stat-allocation-foot').textContent = `${pct(stats.totalCandidates ? stats.allocated / stats.totalCandidates * 100 : 0)} of registered candidates assigned`;
  $('#stat-capacity-foot').textContent = `${number(stats.capacity)} total seats · ${pct(stats.utilisation)} utilised`;
  $('#stat-queue-foot').textContent = `${number(stats.queueSize)} candidates waiting in FIFO queue`;
  $('#plan-status').textContent = stats.locked ? 'PLAN LOCKED' : 'PLAN UNLOCKED';
  $('#plan-status').classList.toggle('locked', stats.locked);
  $('#plan-status').classList.toggle('unlocked', !stats.locked);
  $('#toggle-lock-btn').textContent = stats.locked ? 'Unlock seating plan' : 'Lock seating plan';
  $('#allocate-main').disabled = stats.locked;
  $('#allocate-btn').disabled = stats.locked;
  $('#simulate-failure-btn').disabled = stats.locked || stats.checkedIn > 0;
  $('#undo-allocation-btn').disabled = stats.locked || stats.undoAvailable === 0;
}

async function refreshDashboard() {
  const data = await request('/api/dashboard');
  state.dashboard = data.stats;
  updateStats(data.stats);
  renderCentres(data.centres);
  return data;
}

async function loadCandidates() {
  const query = $('#candidate-filter').value.trim();
  try {
    const data = await request(`/api/candidates?q=${encodeURIComponent(query)}&limit=100`);
    state.candidates = data.candidates;
    $('#candidate-count-label').textContent = `${number(data.total)} match${data.total === 1 ? '' : 'es'}`;
    $('#candidate-rows').innerHTML = data.candidates.length ? data.candidates.map(c => {
      const badge = c.checkedIn ? '<span class="table-badge badge-checked">CHECKED IN</span>' : c.allocated ? '<span class="table-badge badge-allocated">ALLOCATED</span>' : '<span class="table-badge badge-unallocated">UNALLOCATED</span>';
      const allocation = c.allocated ? `${escapeHtml(c.city)} · H${c.hall} / R${c.row} / S${c.seat}` : '—';
      return `<tr><td class="id-cell">${escapeHtml(c.id)}</td><td class="candidate-name-cell"><b>${escapeHtml(c.name)}</b><small>Candidate record</small></td><td class="pref-cell">${escapeHtml(c.preference1)}${c.preference2 ? ` <span style="color:#57685a">→</span> ${escapeHtml(c.preference2)}` : ''}</td><td>${allocation}</td><td>${badge}</td><td><button class="row-action" data-search-id="${escapeHtml(c.id)}">Inspect ↗</button></td></tr>`;
    }).join('') : '<tr><td colspan="6" class="empty-cell">No matching candidates. Try another ID or name.</td></tr>';
  } catch (error) { toast(error.message, true); }
}

function renderCandidateDetail(c, comparisons) {
  $('#candidate-detail-panel').hidden = false;
  $('#candidate-detail').innerHTML = `<div class="detail-grid"><div class="detail-item"><span>APPLICATION ID</span><b>${escapeHtml(c.id)}</b></div><div class="detail-item"><span>CANDIDATE</span><b>${escapeHtml(c.name)}</b></div><div class="detail-item"><span>PREFERENCE 01</span><b>${escapeHtml(c.preference1 || '—')}</b></div><div class="detail-item"><span>PREFERENCE 02</span><b>${escapeHtml(c.preference2 || '—')}</b></div><div class="detail-item"><span>RECORD STATUS</span><b>${c.checkedIn ? 'Checked in' : c.allocated ? 'Allocated' : 'Unallocated'}</b></div><div class="detail-item"><span>BST KEY COMPARISONS</span><b>${number(comparisons ?? '—')}</b></div></div><div class="detail-allocation">${c.allocated ? `<strong>Assigned seat:</strong> ${escapeHtml(c.centreName)} · Hall ${c.hall} · Row ${c.row} · Seat ${c.seat}` : '<strong>Assignment:</strong> No seat currently allocated.'}</div>`;
  setDsa('candidateSearch', {steps: ['Start at the BST root and compare the requested application ID.', `The search visited ${number(comparisons)} node${comparisons === 1 ? '' : 's'} before reaching this record.`, 'The C++ API returned this exact record from the BST index.']});
  $('#candidate-detail-panel').scrollIntoView({behavior:'smooth', block:'nearest'});
}

async function searchCandidate(id) {
  if (!id) return;
  try {
    const data = await request(`/api/candidate?id=${encodeURIComponent(id)}`);
    if (!data.ok) { toast(data.message, true); setDsa('candidateSearch', {steps: ['Start at the BST root.', `Compare and follow a child pointer for ${number(data.comparisons)} node(s).`, 'A null link was reached; no matching candidate exists.']}); return; }
    renderCandidateDetail(data.candidate, data.comparisons);
    if (state.view === 'seating') {
      $('#seat-search-result').innerHTML = `<b>${escapeHtml(data.candidate.name)}</b><br>${escapeHtml(data.candidate.id)}<br>${data.candidate.allocated ? `${escapeHtml(data.candidate.city)} · Hall ${data.candidate.hall}, Row ${data.candidate.row}, Seat ${data.candidate.seat}` : 'No seat allocated.'}<br><small>${number(data.comparisons)} BST comparisons</small>`;
      if (data.candidate.allocated) { state.selectedCentre = data.candidate.centreId; $('#seat-centre').value = state.selectedCentre; updateHallOptions(); state.selectedHall = data.candidate.hall; $('#seat-hall').value = String(state.selectedHall); await loadSeatMap(); highlightSeat(data.candidate.row - 1, data.candidate.seat - 1); }
    }
  } catch (error) { toast(error.message, true); }
}

function updateHallOptions() {
  const selected = $('#seat-centre')?.value || state.selectedCentre;
  const centre = state.centres.find(c => c.id === selected);
  if (!centre || !$('#seat-hall')) return;
  const previous = Number($('#seat-hall').value || state.selectedHall || 1);
  $('#seat-hall').innerHTML = centre.halls.map(h => `<option value="${h.number}">Hall ${String(h.number).padStart(2,'0')} · ${h.rows} × ${h.cols}</option>`).join('');
  $('#seat-hall').value = String(centre.halls.some(h => h.number === previous) ? previous : 1);
  state.selectedCentre = selected;
  state.selectedHall = Number($('#seat-hall').value || 1);
}

async function loadSeatMap() {
  if (!state.centres.length) return;
  const centre = $('#seat-centre').value || state.selectedCentre || state.centres[0].id;
  const hall = Number($('#seat-hall').value || 1);
  state.selectedCentre = centre; state.selectedHall = hall;
  try {
    const map = await request(`/api/seats?centre=${encodeURIComponent(centre)}&hall=${hall}`);
    if (map.ok === false) { $('#seating-grid').innerHTML = `<div class="empty-state">${escapeHtml(map.message)}</div>`; return; }
    const occupied = map.seats.flat().filter(Boolean).length;
    $('#seat-occupancy').textContent = `${occupied} / ${map.rows * map.cols} seats occupied`;
    $('#hall-title').textContent = `Hall ${String(map.hall).padStart(2,'0')}`;
    $('#hall-subtitle').textContent = `${map.centre} · ${map.city} · ${map.rows} rows × ${map.cols} columns`;
    const template = [];
    template.push('<div class="seat-row-number"></div>');
    for (let c=0;c<map.cols;c++) template.push(`<div class="seat-row-number">${c+1}</div>`);
    const cells = [];
    for (let r=0;r<map.rows;r++) {
      cells.push(`<div class="seat-row-number">${r+1}</div>`);
      for (let c=0;c<map.cols;c++) {
        const record = map.seats[r][c];
        const klass = !record ? 'empty' : record.checkedIn ? 'checked' : 'occupied';
        const label = record ? String(record.id).slice(-3) : '·';
        const title = record ? `${record.id} · ${record.name}` : `Row ${r+1}, seat ${c+1} · Available`;
        cells.push(`<button class="seat-cell ${klass}" data-row="${r}" data-col="${c}" title="${escapeHtml(title)}" aria-label="${escapeHtml(title)}">${label}</button>`);
      }
    }
    $('#seating-grid').innerHTML = `<div class="seating-grid" style="grid-template-columns:24px repeat(${map.cols}, 33px)">${cells.join('')}</div>`;
    state.seatData = map;
    $('#seat-detail').innerHTML = `<span class="seat-detail-icon">↖</span><span>Select a seat to inspect the candidate record.</span>`;
  } catch (error) { $('#seating-grid').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}

function highlightSeat(row, col) {
  if (row == null || col == null || row < 0 || col < 0) return;
  const button = $(`.seat-cell[data-row="${row}"][data-col="${col}"]`);
  if (button) { $$('.seat-cell.selected').forEach(el => el.classList.remove('selected')); button.classList.add('selected'); button.scrollIntoView({behavior:'smooth', block:'nearest', inline:'nearest'}); button.click(); }
}

async function loadQueue() {
  try {
    const data = await request('/api/queue');
    state.queue = data.next || [];
    $('#queue-preview').innerHTML = data.size ? `<b>${number(data.size)} waiting in queue</b><br>${data.next.map((c,i)=>`${i+1}. ${escapeHtml(c.id)} · ${escapeHtml(c.name)}`).join('<br>')}${data.size > data.next.length ? `<br>+ ${data.size-data.next.length} more` : ''}` : 'Queue empty. Prepare a queue before processing check-ins.';
  } catch (error) { $('#queue-preview').textContent = error.message; }
}

async function loadAudit() {
  try {
    const data = await request('/api/audit');
    state.audit = data.events;
    $('#audit-total').textContent = `${number(data.total)} EVENTS`;
    const renderEvent = (event, index, compact=false) => {
      const match = event.match(/^\[(.*?)\]\s*(.*)$/);
      const time = match ? match[1] : 'Session event';
      const message = match ? match[2] : event;
      const icon = /allocat|seat/i.test(message) ? '▦' : /check-in|checked in/i.test(message) ? '✓' : /centre|center|offline|failure/i.test(message) ? '!' : /candidate|csv|register/i.test(message) ? '⌘' : '≡';
      if (compact) return `<div class="event-row"><div class="event-mark">${icon}</div><div class="event-copy"><b>${escapeHtml(message)}</b><small>${escapeHtml(time)}</small></div></div>`;
      return `<div class="audit-event"><div class="audit-icon">${icon}</div><div><b>${escapeHtml(message)}</b><small>Linked-list node · Event ${String(Math.max(1, data.total - data.events.length + index + 1)).padStart(3,'0')}</small></div><time>${escapeHtml(time)}</time></div>`;
    };
    $('#audit-events').innerHTML = data.events.length ? [...data.events].reverse().map((event,index)=>renderEvent(event,index)).join('') : '<div class="empty-state">No operations have been recorded yet.</div>';
    $('#recent-events').innerHTML = data.events.length ? [...data.events].slice(-4).reverse().map((event,index)=>renderEvent(event,index,true)).join('') : '<div class="empty-state">No events yet. Allocate seats to create the first operation event.</div>';
  } catch (error) { toast(error.message, true); }
}

async function refreshAll() {
  try {
    await refreshDashboard();
    await Promise.all([loadCandidates(), loadAudit(), loadQueue()]);
    if (state.view === 'seating') await loadSeatMap();
  } catch (error) {
    toast(`Could not connect to the C++ engine. Start ./run.sh in the project folder. ${error.message}`, true);
  }
}

async function perform(path, form = {}, operation = null, successMessage = null) {
  try {
    const result = await request(path, form, 'POST');
    if (operation) setDsa(operation);
    if (!result.ok) {
      toast(result.message || 'Operation failed.', true);
      if (result.requiresConfirmation && path === '/api/plan/lock') return perform(path, {...form, allowPartial:'1'}, operation, successMessage);
      return result;
    }
    toast(successMessage || result.message || 'Operation completed.');
    await refreshAll();
    if (state.view === 'seating') await loadSeatMap();
    return result;
  } catch (error) { toast(error.message, true); return null; }
}

function populateOperationsSelect() {
  const select = $('#failure-centre');
  const active = state.centres.filter(c => c.available);
  select.innerHTML = active.map(c => `<option value="${escapeHtml(c.id)}">${escapeHtml(c.city)} · ${escapeHtml(c.id)}</option>`).join('');
  if (!active.length) select.innerHTML = '<option value="">No active centres</option>';
}

// Navigation and quick links
$$('.nav-item').forEach(btn => btn.addEventListener('click', () => navigate(btn.dataset.view)));
$$('[data-nav]').forEach(btn => btn.addEventListener('click', () => navigate(btn.dataset.nav)));
$('#dismiss-notice').addEventListener('click', () => $('.notice').remove());
$('#refresh-btn').addEventListener('click', async () => { await refreshAll(); toast('Application state refreshed from C++.'); });
$('#export-candidates').addEventListener('click', () => { window.location.href = '/api/export/candidates.csv'; setDsa('candidatesList'); toast('Candidate CSV export requested.'); });
$('#allocate-main').addEventListener('click', async () => { setDsa('allocation'); await perform('/api/allocate', {}, 'allocation'); });
$('#allocate-btn').addEventListener('click', async () => { await perform('/api/allocate', {}, 'allocation'); });
$('#quick-allocate').addEventListener('click', async () => { await perform('/api/allocate', {}, 'allocation'); });

$('#centre-form').addEventListener('submit', async e => {
  e.preventDefault();
  const form = Object.fromEntries(new FormData(e.currentTarget).entries());
  const result = await perform('/api/centres/add', form, 'centreAdd');
  if (result?.ok) { e.currentTarget.reset(); toast(`Centre added with ${number(result.capacity)} seats.`); }
});

$('#candidate-filter').addEventListener('input', () => { clearTimeout(state.filterTimer); state.filterTimer = setTimeout(loadCandidates, 180); setDsa('candidatesList'); });
$('#candidate-rows').addEventListener('click', e => { const button = e.target.closest('[data-search-id]'); if (button) searchCandidate(button.dataset.searchId); });
$('#close-candidate-detail').addEventListener('click', () => { $('#candidate-detail-panel').hidden = true; });
$('#candidate-form').addEventListener('submit', async e => {
  e.preventDefault(); const form = Object.fromEntries(new FormData(e.currentTarget).entries());
  const result = await perform('/api/candidates/add', form, 'candidateRegister');
  if (result?.ok) e.currentTarget.reset();
});
$('#csv-import').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try { const csv = await file.text(); const result = await perform('/api/import', {csv}, 'import', `Imported CSV: ${file.name}`); if (result?.ok) toast(`CSV processed: ${result.added} added, ${result.skipped} skipped.`); }
  catch (error) { toast(`Could not read CSV: ${error.message}`, true); }
  e.target.value = '';
});
$('#seat-centre').addEventListener('change', () => { updateHallOptions(); setDsa('seating'); loadSeatMap(); });
$('#seat-hall').addEventListener('change', () => { state.selectedHall = Number($('#seat-hall').value); setDsa('seating'); loadSeatMap(); });
$('#seating-grid').addEventListener('click', e => {
  const button = e.target.closest('.seat-cell'); if (!button) return;
  $$('.seat-cell.selected').forEach(el => el.classList.remove('selected')); button.classList.add('selected');
  const row = Number(button.dataset.row), col = Number(button.dataset.col), record = state.seatData?.seats?.[row]?.[col];
  if (record) {
    $('#seat-detail').innerHTML = `<span class="seat-detail-icon">⌘</span><span><strong>${escapeHtml(record.id)} · ${escapeHtml(record.name)}</strong> &nbsp; / &nbsp; ${record.checkedIn ? 'Checked in' : 'Not checked in'}</span><button class="row-action" data-open-seat-candidate="${escapeHtml(record.id)}" style="margin-left:auto">Inspect record ↗</button>`;
  } else {
    $('#seat-detail').innerHTML = `<span class="seat-detail-icon">＋</span><span><strong>Available seat</strong> &nbsp; / &nbsp; Row ${row+1}, Seat ${col+1}. No candidate index is stored in this cell.</span>`;
  }
});
$('#seat-detail').addEventListener('click', e => { const b = e.target.closest('[data-open-seat-candidate]'); if (b) searchCandidate(b.dataset.openSeatCandidate); });
$('#seat-search-form').addEventListener('submit', async e => { e.preventDefault(); const id = new FormData(e.currentTarget).get('id'); await searchCandidate(String(id || '').trim()); });
$('#prepare-queue-btn').addEventListener('click', async () => { await perform('/api/queue/prepare', {}, 'queuePrepare'); });
$('#process-queue-btn').addEventListener('click', async () => { await perform('/api/queue/process', {}, 'queueProcess'); });
$('#undo-checkin-btn').addEventListener('click', async () => { if (confirm('Undo the most recent check-in? The FIFO queue will need to be prepared again.')) await perform('/api/checkin/undo', {}, 'checkinUndo'); });
$('#simulate-failure-btn').addEventListener('click', async () => {
  const centreId = $('#failure-centre').value; if (!centreId) return toast('There are no active centres to simulate.', true);
  const centre = state.centres.find(c=>c.id===centreId);
  if (!confirm(`Mark ${centre?.name || centreId} unavailable and attempt to reallocate its candidates? You can undo this allocation change while the plan is unlocked.`)) return;
  const result = await perform('/api/centre/fail', {centreId}, 'disruption');
  if (result?.ok) { $('#failure-result').hidden = false; $('#failure-result').innerHTML = `<b>Disruption report</b><br>${number(result.displaced)} candidates displaced<br>${number(result.reallocated)} reallocated<br>${number(result.stranded)} still unallocated`; }
});
$('#undo-allocation-btn').addEventListener('click', async () => { if (confirm('Restore the previous allocation snapshot?')) await perform('/api/allocation/undo', {}, 'undoAllocation'); });
$('#toggle-lock-btn').addEventListener('click', async () => {
  const locked = !!state.dashboard?.locked;
  if (locked) {
    const code = prompt('This is an authorised change. Type UNLOCK to proceed:');
    if (code !== 'UNLOCK') return toast('Unlock cancelled.');
    await perform('/api/plan/lock', {locked:'0'}, 'planLock');
  } else {
    const partial = (state.dashboard?.unallocated || 0) > 0;
    if (!confirm(partial ? `Lock the seating plan with ${state.dashboard.unallocated} unallocated candidate(s) visible in the exception count?` : 'Lock the seating plan? Allocation changes will be disabled.')) return;
    await perform('/api/plan/lock', {locked:'1', allowPartial: partial ? '1' : '0'}, 'planLock');
  }
});

// Keyboard shortcut: Command/Ctrl + K focuses candidate search.
document.addEventListener('keydown', e => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); navigate('candidates'); $('#candidate-filter').focus(); } });

(async function boot() {
  setDsa('overview');
  try {
    await refreshAll();
    navigate('dashboard');
    setDsa('overview');
  } catch (error) {
    toast(`Unable to reach C++ server: ${error.message}. Run ./run.sh from the project directory.`, true);
  }
})();
